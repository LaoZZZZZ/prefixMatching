#ifndef SUFFIX_H
#define SUFFIX_H
namespace prefixMatching{
class Suffix
{
public:
    Suffix();

};
}
#endif // SUFFIX_H
