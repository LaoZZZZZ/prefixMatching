/*
 * Copyright 2014, Lu Zhao <luzhao1986@gmail.com>
 *
 * This file is part of suffix matching project.
 */
#ifndef REORDERDRIVE_H
#define REORDERDRIVE_H
#include <memory>
#include <fstream>
#include "suffixparam.h"
#include "filesplittor.h"
#include "suffixreadsloader.h"
#include "linearmatching.h"
#include "treematching.h"
#include "treematchingmultipleway.h"
#include "snowball.h"
using std::fstream;
using std::shared_ptr;
using std::unique_ptr;
namespace prefixMatching{
class reorderDrive
{
public:
    reorderDrive(std::shared_ptr<suffixParam>& params);
    void drive(){

        this->_readsLoader->loadAll(this->_pool);
        std::unique_ptr<matchingAlgorithm> alg;
        if(this->_params->dataStructure() == TREE)
            alg.reset(new treeMatching(this->_pool,this->_order));
        else if(this->_params->dataStructure() == TRIE)
            alg.reset(new linearMatching(this->_pool,this->_order));
        else if(this->_params->dataStructure() == TREEMULTIPLE)
            alg.reset(new treeMatchingMultipleWay(this->_pool,this->_order));
        else if(this->_params->dataStructure() == BLOCK){
            alg.reset(new snowBall(this->_pool,this->_order));
        }
        else
            throw 1;

        alg->solution();
        cout<<this->_order.size()<<'\t'<<this->_pool.size()<<endl;
        assert(this->_order.size() == this->_pool.size());
        output();

    }
    ~reorderDrive(){
    }
private:
    void init(){
        suffixReadsLoader* tmp = new suffixReadsLoader(this->_params->format(),this->_params->readFile());
        this->_readsLoader.reset(tmp);
    }
    void output(){

        string outprefix(this->_params->outprefix());

        string original_prefix = outprefix + "_original";
        std::unique_ptr<fileSplittor> original(new fileSplittor(this->_params->format(),original_prefix));
        original->split(this->_pool);

        string processed_prefix = outprefix + "_ordered";
        std::unique_ptr<fileSplittor> processed(new fileSplittor(this->_params->format(),processed_prefix));
        processed->orderSplit(this->_pool,this->_order);


    }
private:
    std::shared_ptr<suffixParam>                      _params;
    std::unique_ptr<suffixReadsLoader>                _readsLoader;
    vector<std::shared_ptr<Read>>                     _pool;
    vector<int>                                       _order;
    int                                               _unmatched;
};
}

#endif // REORDERDRIVE_H
