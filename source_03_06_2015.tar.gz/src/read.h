/*
 * Copyright 2014, Lu Zhao <luzhao1986@gmail.com>
 *
 * This file is part of suffix matching project.
 */

#ifndef READ_H_
#define READ_H_

#include <stdint.h>
#include <sys/time.h>
#include "ds.h"
#include "sstring.h"
#include "filebuf.h"
#include "util.h"

namespace prefixMatching {

typedef UINT64 TReadId;
typedef size_t TReadOff;
typedef int64_t TAlScore;


/**
 * A buffer for keeping all relevant information about a single read.
 */
    struct Read {

	Read() { reset(); }

	Read(const char *nm, const char *seq, const char *ql) { init(nm, seq, ql); }
    ~Read(){
        this->reset();
    }
        /// Return true iff the read (pair) is empty
	bool empty() const {
		return patFw.empty();
	}

	/// Return length of the read in the buffer
	size_t length() const {
		return patFw.length();
	}
    /**
      * write the read to the given stream,
      * could be reverse or forward version
    */
    /*
    void write(std::ostream& os,bool rev){
        if(rev){
            os<<'@'<<this->name<<std::endl;
            BTDnaString Rc;
            os<<Rc<<std::endl;
            os<<'+'<<std::endl;
            this->qual.reverse();
            os<<this->qual<<std::endl;
        }else{

            os<<'@'<<this->name<<std::endl;
            os<<this->patFw<<std::endl;
            os<<'+'<<std::endl;
            os<<this->qual<<std::endl;
        }
    }*/
    //BTString& id(){return this->name;}
    //BTString& quality(){return this->qual;}
    const BTDnaString& fowardSeq()const{return this->patFw;}
    BTDnaString& fowardSeq(){return this->patFw;}
    void        reverseComSeq(BTDnaString& rc)const{
        rc.installReverseComp(patFw);
    }
    /*
    BTDnaString& reversCompSeq(){
        if(this->patRc.empty())
            patRc.installReverseComp(patFw);
        return this->patRc;
    }*/
    const int&  operator[](size_t pos)const{
        return this->patFw[pos];

    }
private:
    void reset() {
        patFw.clear();
        //patRc.clear();
        //qual.clear();
        //name.clear();
    }
    /**
     * Simple init function, used for testing.
     */
    void init(
        const char *nm,
        const char *seq,
        const char *ql)
    {
        reset();
        patFw.installChars(seq);
        //qual.install(ql);
        //constructRevComps();
        //if(nm != NULL) name.install(nm);
    }
	/**
	 * Construct reverse complement of the pattern and the fuzzy
	 * alternative patters.  If read is in colorspace, just reverse
	 * them.
	 */
    // by luzhao
    /*
    void constructRevComps() {
        patRc.installReverseComp(patFw);
    }
    */

private:
    BTDnaString                 patFw;            // forward-strand sequence
   // BTDnaString                 patRc;           // reverse-complement sequence

    //BTString                    qual;             // quality values

    //BTString                    name;      // read name

};


}
#endif /*READ_H_*/
