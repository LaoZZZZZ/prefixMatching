#ifndef TREEMATCHINGMULTIPLEWAY_H
#define TREEMATCHINGMULTIPLEWAY_H
#include "matchingalgorithm.h"
#include "linksuffixtree.h"
namespace prefixMatching{
class treeMatchingMultipleWay : public matchingAlgorithm
{
public:
    treeMatchingMultipleWay(std::vector<std::shared_ptr<Read> >& r, vector<int>& m);
private:
    virtual void constructSolution();
protected:
    void init();
protected:
    std::shared_ptr<linkSuffixTree>                             _suffix;
};
}
#endif // TREEMATCHINGMULTIPLEWAY_H
