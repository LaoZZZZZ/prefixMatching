#include "suffix.h"

namespace prefixMatching {

Suffix::Suffix()
{
}
}
