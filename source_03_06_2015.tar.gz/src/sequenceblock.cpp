#include "sequenceblock.h"

namespace prefixMatching{
sequenceBlock::sequenceBlock(const list<int>& ids):_order(ids)
{
}

}
